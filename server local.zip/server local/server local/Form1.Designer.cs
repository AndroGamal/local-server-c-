﻿namespace server_local
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.list = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.upload_page = new System.Windows.Forms.Panel();
            this.upload = new System.Windows.Forms.Label();
            this.task = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.size_min = new System.Windows.Forms.Label();
            this.size_max = new System.Windows.Forms.Label();
            this.close = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.log = new System.Windows.Forms.TabPage();
            this.log_show = new System.Windows.Forms.TextBox();
            this.Mac_address = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.link = new System.Windows.Forms.LinkLabel();
            this.select3 = new System.Windows.Forms.Button();
            this.js_input = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.start = new System.Windows.Forms.Button();
            this.select2 = new System.Windows.Forms.Button();
            this.css_input = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.select1 = new System.Windows.Forms.Button();
            this.html_input = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.list.SuspendLayout();
            this.panel1.SuspendLayout();
            this.upload_page.SuspendLayout();
            this.task.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.log.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // list
            // 
            this.list.BackColor = System.Drawing.Color.Navy;
            this.list.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.list.Controls.Add(this.panel1);
            this.list.Controls.Add(this.upload_page);
            this.list.Location = new System.Drawing.Point(1, 25);
            this.list.Name = "list";
            this.list.Size = new System.Drawing.Size(200, 443);
            this.list.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.panel1.Controls.Add(this.label2);
            this.panel1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(3, 109);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(192, 100);
            this.panel1.TabIndex = 2;
            this.panel1.Click += new System.EventHandler(this.panel1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 21F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(22, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(140, 32);
            this.label2.TabIndex = 0;
            this.label2.Text = "Show log";
            this.label2.Click += new System.EventHandler(this.label2_Click_1);
            // 
            // upload_page
            // 
            this.upload_page.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.upload_page.Controls.Add(this.upload);
            this.upload_page.Cursor = System.Windows.Forms.Cursors.Hand;
            this.upload_page.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.upload_page.Location = new System.Drawing.Point(3, 3);
            this.upload_page.Name = "upload_page";
            this.upload_page.Size = new System.Drawing.Size(192, 100);
            this.upload_page.TabIndex = 1;
            this.upload_page.Click += new System.EventHandler(this.upload_page_Click);
            // 
            // upload
            // 
            this.upload.AutoSize = true;
            this.upload.Font = new System.Drawing.Font("Microsoft Sans Serif", 21F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.upload.Location = new System.Drawing.Point(7, 32);
            this.upload.Name = "upload";
            this.upload.Size = new System.Drawing.Size(184, 32);
            this.upload.TabIndex = 0;
            this.upload.Text = "upload page";
            this.upload.Click += new System.EventHandler(this.upload_Click);
            // 
            // task
            // 
            this.task.BackColor = System.Drawing.Color.Gray;
            this.task.Controls.Add(this.label5);
            this.task.Controls.Add(this.size_min);
            this.task.Controls.Add(this.size_max);
            this.task.Controls.Add(this.close);
            this.task.Controls.Add(this.label1);
            this.task.Cursor = System.Windows.Forms.Cursors.Default;
            this.task.Location = new System.Drawing.Point(1, 1);
            this.task.Name = "task";
            this.task.Size = new System.Drawing.Size(722, 26);
            this.task.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(3, 6);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(23, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "≡";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // size_min
            // 
            this.size_min.AutoSize = true;
            this.size_min.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.size_min.Cursor = System.Windows.Forms.Cursors.Hand;
            this.size_min.ImageKey = "(none)";
            this.size_min.Location = new System.Drawing.Point(664, 5);
            this.size_min.Name = "size_min";
            this.size_min.Size = new System.Drawing.Size(18, 15);
            this.size_min.TabIndex = 5;
            this.size_min.Text = "ـــ";
            this.size_min.Click += new System.EventHandler(this.label4_Click);
            // 
            // size_max
            // 
            this.size_max.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.size_max.Cursor = System.Windows.Forms.Cursors.Hand;
            this.size_max.ImageKey = "(none)";
            this.size_max.Location = new System.Drawing.Point(683, 5);
            this.size_max.Name = "size_max";
            this.size_max.Size = new System.Drawing.Size(19, 15);
            this.size_max.TabIndex = 4;
            this.size_max.Text = "■";
            this.size_max.Click += new System.EventHandler(this.label3_Click);
            // 
            // close
            // 
            this.close.AutoSize = true;
            this.close.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.close.Cursor = System.Windows.Forms.Cursors.Hand;
            this.close.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.close.Location = new System.Drawing.Point(703, 5);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(17, 15);
            this.close.TabIndex = 3;
            this.close.Text = "X";
            this.close.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Server local";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.log);
            this.tabControl1.Controls.Add(this.Mac_address);
            this.tabControl1.Location = new System.Drawing.Point(203, 29);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(520, 439);
            this.tabControl1.TabIndex = 3;
            this.tabControl1.Visible = false;
            // 
            // log
            // 
            this.log.Controls.Add(this.log_show);
            this.log.Location = new System.Drawing.Point(4, 22);
            this.log.Name = "log";
            this.log.Padding = new System.Windows.Forms.Padding(3);
            this.log.Size = new System.Drawing.Size(512, 413);
            this.log.TabIndex = 0;
            this.log.Text = "log";
            this.log.UseVisualStyleBackColor = true;
            // 
            // log_show
            // 
            this.log_show.Location = new System.Drawing.Point(0, 3);
            this.log_show.Multiline = true;
            this.log_show.Name = "log_show";
            this.log_show.ReadOnly = true;
            this.log_show.Size = new System.Drawing.Size(510, 410);
            this.log_show.TabIndex = 0;
            // 
            // Mac_address
            // 
            this.Mac_address.Location = new System.Drawing.Point(4, 22);
            this.Mac_address.Name = "Mac_address";
            this.Mac_address.Padding = new System.Windows.Forms.Padding(3);
            this.Mac_address.Size = new System.Drawing.Size(512, 413);
            this.Mac_address.TabIndex = 1;
            this.Mac_address.Text = "Mac address";
            this.Mac_address.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.link);
            this.panel2.Controls.Add(this.select3);
            this.panel2.Controls.Add(this.js_input);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.start);
            this.panel2.Controls.Add(this.select2);
            this.panel2.Controls.Add(this.css_input);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.select1);
            this.panel2.Controls.Add(this.html_input);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(202, 29);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(520, 439);
            this.panel2.TabIndex = 1;
            // 
            // link
            // 
            this.link.AutoSize = true;
            this.link.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.link.Location = new System.Drawing.Point(243, 115);
            this.link.Name = "link";
            this.link.Size = new System.Drawing.Size(33, 17);
            this.link.TabIndex = 10;
            this.link.TabStop = true;
            this.link.Text = "link";
            this.link.Visible = false;
            this.link.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.link_LinkClicked);
            // 
            // select3
            // 
            this.select3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.select3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.select3.Location = new System.Drawing.Point(441, 87);
            this.select3.Name = "select3";
            this.select3.Size = new System.Drawing.Size(75, 30);
            this.select3.TabIndex = 9;
            this.select3.Text = "Select file";
            this.select3.UseVisualStyleBackColor = true;
            // 
            // js_input
            // 
            this.js_input.Location = new System.Drawing.Point(75, 92);
            this.js_input.Name = "js_input";
            this.js_input.Size = new System.Drawing.Size(360, 20);
            this.js_input.TabIndex = 8;
            this.js_input.Text = "Enter HTML";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 96);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "JS File";
            // 
            // start
            // 
            this.start.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.start.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.start.Location = new System.Drawing.Point(12, 399);
            this.start.Name = "start";
            this.start.Size = new System.Drawing.Size(499, 30);
            this.start.TabIndex = 6;
            this.start.Text = "Start Server Website";
            this.start.UseVisualStyleBackColor = true;
            this.start.Click += new System.EventHandler(this.start_Click);
            // 
            // select2
            // 
            this.select2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.select2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.select2.Location = new System.Drawing.Point(440, 51);
            this.select2.Name = "select2";
            this.select2.Size = new System.Drawing.Size(75, 30);
            this.select2.TabIndex = 5;
            this.select2.Text = "Select file";
            this.select2.UseVisualStyleBackColor = true;
            // 
            // css_input
            // 
            this.css_input.Location = new System.Drawing.Point(74, 56);
            this.css_input.Name = "css_input";
            this.css_input.Size = new System.Drawing.Size(360, 20);
            this.css_input.TabIndex = 4;
            this.css_input.Text = "Enter HTML";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "CSS File";
            // 
            // select1
            // 
            this.select1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.select1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.select1.Location = new System.Drawing.Point(440, 15);
            this.select1.Name = "select1";
            this.select1.Size = new System.Drawing.Size(75, 30);
            this.select1.TabIndex = 2;
            this.select1.Text = "Select file";
            this.select1.UseVisualStyleBackColor = true;
            this.select1.Click += new System.EventHandler(this.select1_Click);
            // 
            // html_input
            // 
            this.html_input.Location = new System.Drawing.Point(74, 20);
            this.html_input.Name = "html_input";
            this.html_input.Size = new System.Drawing.Size(360, 20);
            this.html_input.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "HTML File";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(724, 470);
            this.Controls.Add(this.task);
            this.Controls.Add(this.list);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Server local";
            this.Resize += new System.EventHandler(this.Form1_Resize);
            this.list.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.upload_page.ResumeLayout(false);
            this.upload_page.PerformLayout();
            this.task.ResumeLayout(false);
            this.task.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.log.ResumeLayout(false);
            this.log.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel list;
        private System.Windows.Forms.Panel upload_page;
        private System.Windows.Forms.Label upload;
        private System.Windows.Forms.Panel task;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label close;
        private System.Windows.Forms.Label size_max;
        private System.Windows.Forms.Label size_min;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage log;
        private System.Windows.Forms.TabPage Mac_address;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox log_show;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox html_input;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button select1;
        private System.Windows.Forms.Button select2;
        private System.Windows.Forms.TextBox css_input;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button start;
        private System.Windows.Forms.Button select3;
        private System.Windows.Forms.TextBox js_input;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.LinkLabel link;
    }
}


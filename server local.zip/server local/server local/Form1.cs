﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace server_local
{
    public partial class Form1 : Form
    {
        TcpClient clientSocket;
        TcpListener serverSocket;
        NetworkStream stream;
        Thread write;
        bool star=false;
        OpenFileDialog open = new OpenFileDialog();
        int w = 204;
        string s, m;
        Process p;
        private void read()
        {
            try
            {

                while (true)
                {
                    write = new Thread(r);
                    clientSocket = serverSocket.AcceptTcpClient();
                    write.Start();
                }
            }
            catch (Exception e) { }
        }
        private void r()
        {
            try
            {
                stream = clientSocket.GetStream();
                byte[] v = new byte[500000];
                stream.Read(v, 0, clientSocket.ReceiveBufferSize);
                s = System.Text.Encoding.ASCII.GetString(v);
                stream.Write(Encoding.UTF8.GetBytes("HTTP/1.0 200 \r\n"), 0, 15);
                stream.Write(Encoding.UTF8.GetBytes("Content type: text/html \r\n"), 0, 26);
                stream.Write(Encoding.UTF8.GetBytes("Content length: " + m.Length + "\r\n"), 0, m.Length.ToString().Length + 18);
                stream.Write(Encoding.UTF8.GetBytes("\r\n"), 0, 2);
                stream.Write(Encoding.UTF8.GetBytes(m + "\r\n"), 0, m.Length + 2);
                stream.Flush();
                stream.Close();
                clientSocket.Close();
         SetTextBox(log_show,s);
            }
            catch (Exception e) { }
        }

        public void SetTextBox(TextBox textbox, String text)
        {
            if (InvokeRequired)
            {
                this.Invoke((MethodInvoker)delegate() { SetTextBox(textbox, text); });
                return;
            }
            textbox.Text += text;
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
            if(star){
            serverSocket.Stop();
            write.Abort();
            
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Normal)
                WindowState = FormWindowState.Maximized;
            else WindowState = FormWindowState.Normal;
        
        }

        private void label4_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        void anmation_close()
        {
            Refresh();
            for (int i = 0; i < 199; i++)
            {
                list.Location = new Point(1 - i, 25);
            }
            tabControl1.Location = new Point( 4, 29);
            panel2.Location = new Point(4, 29);
            w = 4;
            repaint();
            list.Visible = false;
        }
        void anmation_open()
        {
            list.Visible = true;
            tabControl1.Location = new Point(204, 29);
            panel2.Location = new Point(204, 29);
            w = 204;
            repaint();
            int y = list.Location.X;
            for (int i = 0; i < 199; i++)
            {
                list.Location = new Point(y + i, 25);
            }
        }
        private void label5_Click(object sender, EventArgs e)
        {

            if (list.Visible) anmation_close();
            else anmation_open();
            
        }
        void repaint() {
            panel2.Size = new Size(Size.Width - w, Size.Height - 31);          
            html_input.Size = new Size(panel2.Size.Width - 160, 20);
            css_input.Size = new Size(panel2.Size.Width - 160, 20);
            js_input.Size = new Size(panel2.Size.Width - 160, 20);
            select1.Location = new Point(panel2.Size.Width - 80, 15);
            select2.Location = new Point(panel2.Size.Width - 80, 51);
            select3.Location = new Point(panel2.Size.Width - 80, 87);
            start.Location = new Point(12, panel2.Size.Height - 40);
            start.Size = new Size(panel2.Size.Width - 21, 30);
            tabControl1.Size = new Size(Size.Width - w, Size.Height - 31);
            log_show.Size = new Size(tabControl1.Size.Width - 10, tabControl1.Size.Height - 29);
            link.Location = new Point(panel2.Size.Width/2-link.Size.Width/2, 115);
        }
      
        private void Form1_Resize(object sender, EventArgs e)
        {
            list.Size = new Size(200, Size.Height - 26);
            task.Size = new Size(Size.Width - 2, 26);
            close.Location = new Point(task.Size.Width - 19, 5);
            size_max.Location = new Point(task.Size.Width - 39, 5);
            size_min.Location = new Point(task.Size.Width - 58, 5);
            repaint();
          
        }

        private void upload_page_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;
            tabControl1.Visible = false;

        }

        private void panel1_Click(object sender, EventArgs e)
        {
            tabControl1.Visible = true;
            panel2.Visible = false;

        }

        private void upload_Click(object sender, EventArgs e)
        {
            upload_page_Click(sender, e);
        }

        private void label2_Click_1(object sender, EventArgs e)
        {
            panel1_Click(sender, e);
        }

        private void start_Click(object sender, EventArgs e)
        {
            if (open.FileName == "") { new message().show("please enter html file that you want to upload."); }
            else
            {
                if(!star){
                StreamReader reader = new StreamReader(open.FileName);
                m = reader.ReadToEnd();
                Thread n = new Thread(read);
                serverSocket = new TcpListener(8080);
                serverSocket.Start();
                n.Start();
                link.Text = "http://" + get_ip() + ":8080";
                link.Visible = true;
                link.Location = new Point(panel2.Size.Width / 2 - link.Size.Width / 2, 115);
                start.Text = "Stop Server Website";
                star = true;
                }
                else {
                    serverSocket.Stop();
                    write.Abort();
                    star = false;
                    start.Text = "Start Server Website";
                    link.Visible = false;
                }
            }
            }
        string get_ip()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            return "null";
        }

        private void select1_Click(object sender, EventArgs e)
        {   
            open.Filter = "Html-Files(*.html)|*.html|Pdf-Files(*.pdf)|*.pdf";
            open.ShowDialog();
            html_input.Text = open.FileName;
        }

        private void link_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            p = new Process();
            p.StartInfo.FileName = "http://" + get_ip() + ":8080";
            p.Start();
        }

      

    }
}
